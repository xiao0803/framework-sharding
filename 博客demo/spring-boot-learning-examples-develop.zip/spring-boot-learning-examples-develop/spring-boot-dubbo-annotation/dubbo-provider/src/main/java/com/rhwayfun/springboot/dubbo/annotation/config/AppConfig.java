package com.rhwayfun.springboot.dubbo.annotation.config;

import org.springframework.context.annotation.Configuration;

/**
 * @author rhwayfun
 * @since 0.0.1
 */
@Configuration
public class AppConfig {
}
