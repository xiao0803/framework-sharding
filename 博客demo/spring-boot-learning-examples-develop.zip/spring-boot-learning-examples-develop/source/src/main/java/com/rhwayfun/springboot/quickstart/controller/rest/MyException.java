package com.rhwayfun.springboot.quickstart.controller.rest;

/**
 * Created by chubin on 2017/2/12.
 */
public class MyException extends RuntimeException {

    public MyException(String message) {
        super(message);
    }

}
