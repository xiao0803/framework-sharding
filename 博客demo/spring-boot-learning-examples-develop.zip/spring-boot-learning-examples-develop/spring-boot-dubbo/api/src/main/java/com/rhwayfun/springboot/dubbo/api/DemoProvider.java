package com.rhwayfun.springboot.dubbo.api;

/**
 * @author rhwayfun
 * @since 0.0.1
 */
public interface DemoProvider {

    String sayHello(String name);

}
